{ config, pkgs, ... }:

{
  home.username = "paulg";
  home.homeDirectory = "/home/paulg";

  home.stateVersion = "26.05";

  programs.home-manager.enable = true;
}
